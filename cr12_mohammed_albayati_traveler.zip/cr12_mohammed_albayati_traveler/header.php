<!DOCTYPE html>

<html <?php language_attributes(); ?> class="no‐js">
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
   <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
   <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>

<link href="https://fonts.googleapis.com/css?family=Text+Me+One" rel="stylesheet">

 <link href="<?php bloginfo('stylesheet_url');?> " rel="stylesheet">
 <link href="<?php bloginfo('template_url');?>/css/bootstrap.css " rel="stylesheet">

   <!-- Custom styles for this template -->

<style type="text/css">
  
   
</style>


<?php if ( is_singular() && pings_open( get_queried_object() ) ) { ?>
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php } ?>

   <?php wp_head(); ?>

 </head>
 <body>
   <div class="blog-masthead">
    
       <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
		  <a class="navbar-brand" href="#"> <?php bloginfo('name'); ?>
       <p class="lead blog-description"><?php bloginfo('description'); ?></p>
    </a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <?php mainnav() ?>



     	</div>
       </nav>
  