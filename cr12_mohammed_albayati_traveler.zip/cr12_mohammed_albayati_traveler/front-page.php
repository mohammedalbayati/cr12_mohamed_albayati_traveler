
<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ahmed_first_project
 */

get_header(); ?>


 </div>
   <div class="con" style="width: 100%;">
     <div class="jumbotro">
    <div class="namee">
      <h1>Code Review 12</h1> 
       <h4 class="blog-title"><?php bloginfo('name'); ?></h4>
       <p class="lead blog-description"> <?php bloginfo('description'); ?></p>
     </div>
 
  </div>
</div>
<section class="showcase">
     <div class="container">
       
       <a href="http://localhost/codefactory_wp/7-2/" class="btn btn-primary btn-lg">Blog</a>
     </div>
   </section>
   <section class="boxes">
     <div class="container">
       <div class="row">
         <div class="col-md-4">
           <div class="box">
             <i class="fa fa-paper-plane" aria-hidden="true"></i>
             <h3>Lorem Ipsum Dolor</h3>
             <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>
           </div>
         </div>
         <div class="col-md-4">
           <div class="box">
             <i class="fa fa-comments" aria-hidden="true"></i>
             <h3>Lorem Ipsum Dolor</h3>
             <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
           </div>
         </div>
         <div class="col-md-4">
           <div class="box">
             <i class="fa fa-power-off" aria-hidden="true"></i>
             <h3>Lorem Ipsum Dolor</h3>
             <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
           </div>
         </div>
       </div>
     </div>
   </section>

<?php get_sidebar(); ?>




<?php
get_footer();
?>


