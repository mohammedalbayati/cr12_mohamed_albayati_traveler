<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ahmed_first_project
 */

get_header(); ?>


 </div>
   <div class="con" style="width: 100%;">
     <div class="jumbotro">
    <div class="namee">
      <h1> Blog </h1> 
       <h4 class="blog-title"><?php bloginfo('name'); ?></h4>
       <p class="lead blog-description"> <?php bloginfo('description'); ?></p>
     </div>
 
  </div>
</div>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="module">
	
				  <div class="row">


		<?php
		if ( have_posts() ) : ?>

			<header class="page-header">
				<center class='container'> 
		
				<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="archive-description">', '</div> <br>' );
				?>
					</center>
			</header><!-- .page-header -->

<br>
			<?php
			/* Start the Loop */
		while ( have_posts() ) : the_post();
?>

<div class="card" >
 <?php if(has_post_thumbnail()) : ?>
<img src="<?php the_post_thumbnail();?>
<?php endif;?>
  <div class="card-body">
    <a href="<?php the_permalink();?>" class="card-title"> - <?php the_title(); ?> - </a>
    <p class="card-text"><?php the_excerpt();// blog post content ?></p>
  </div>

    <li class="list-group-item"> Date : <?php the_date(); // blog post date ?></li>
  
  <div class="card-body">
 
    By :  <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); // href to author posts ?>" class="card-link"><?php the_author(); // blog post author ?></a>
  </div>
</div>
<?php
			// End the loop.
			endwhile;
?>

<?php else:  ?>
<p><?php echo "‘No Posts Found’"; ?></p>
<?php endif; ?>
		
</div>

</section>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>




<?php
get_footer();
?>
