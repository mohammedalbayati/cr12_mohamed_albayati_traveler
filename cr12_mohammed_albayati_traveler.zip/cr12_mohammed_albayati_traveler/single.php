<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package ahmed_first_project
 */

get_header(); ?>


 </div>
   <div class="con" style="width: 100%;">
     <div class="jumbotro">
    <div class="namee">
      <h1> Blog </h1> 
       <h4 class="blog-title"><?php bloginfo('name'); ?></h4>
       <p class="lead blog-description"> <?php bloginfo('description'); ?></p>
     </div>
 
  </div>
</div>

	<div id="primary" class="content-area" style="width: 88%; margin: 0 auto;">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) : the_post();

			get_template_part( 'template-parts/content', get_post_type() );

			the_post_navigation();

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->
<?php get_sidebar(); ?>




<?php
get_footer();
?>
